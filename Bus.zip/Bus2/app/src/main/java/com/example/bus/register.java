package com.example.bus;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(register.this,MainActivity.class);
                startActivity(intent);
            }
        });
        TextView email = findViewById(R.id.email);
        String input_email = email.getText().toString();
        TextView  username = findViewById(R.id.username);
        String input_user = username.getText().toString();
        TextView password1 = findViewById(R.id.password1);
        String input_password = password1.getText().toString();
        TextView password2 = findViewById(R.id.password2);
        String input_password2 = password2.getText().toString();

        user information = new user(email,username,password1);
        ArrayList<user> data = new ArrayList<>();
        data.add(information);
        for(int i = 0; i<data.size();i++){
            for(int j = 0; j<information[i].size(); j++) {
                if(information.getUser() =  ){



                    AlertDialog.Builder builder1 = new AlertDialog.Builder(register.this);
                    builder1.setMessage("This user is already takrn.");
                    builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getApplicationContext(),"enter new username",Toast.LENGTH_SHORT).show();
                        }
                    });
                }else if(password1.length() != 8){
                    AlertDialog.Builder builder2 = new AlertDialog.Builder(register.this);
                    builder2.setMessage("Your password must be at least 8 character");
                    builder2.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getApplicationContext(),"enter password again",Toast.LENGTH_SHORT).show();
                        }
                    });
                }else if(password1 != password2){
                    AlertDialog.Builder builder3 = new AlertDialog.Builder(register.this);
                    builder3.setMessage("Password dose nit match");
                    builder3.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getApplicationContext(),"enter password again",Toast.LENGTH_SHORT).show();
                        }
                    });
                }else{
                    ImageView register = findViewById(R.id.register);
                    register.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent2 = new Intent(register.this,signIn.class);
                            startActivity(intent2);
                        }
                    });
                }
            }
        }

    }
}
