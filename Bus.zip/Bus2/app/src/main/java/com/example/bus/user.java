package com.example.bus;

import android.widget.TextView;

import java.sql.Array;
import java.util.ArrayList;

public class user {
    public TextView userName;
    public TextView password;
    public TextView email;
    public user(TextView email, TextView userName, TextView password){
        this.email = email;
        this.password = password;
        this.userName = userName;

        ArrayList<TextView> userData = new ArrayList<>();
        userData.add(email);
        userData.add(userName);
        userData.add(password);
        ArrayList<Array> information = new ArrayList<>();
        information.add((Array) userData);
        for (int i = 0; i<information.size();i++){
            if(userName = information[i][1]){

                }

        }
    }
    public String getUser(){
        return userName.toString();
    }
    public String getPassword(){
        return password.toString();
    }
    public String getEmail(){
        return email.toString();
    }

}
