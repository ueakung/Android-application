package com.example.bus;
import java.util.ArrayList;
public class id {
    private ArrayList id;
    public id(String id,String password){ //register สมัคร
        this.id=new ArrayList<String>();
        this.id.add(id);
        this.id.add(password); //register สมัคร
    }
    public boolean login(String id,String password){
        ArrayList login=new ArrayList<String>();
        login.add(id);
        login.add(password);
        if(this.id.equals(login)){
            return true;
        }
        return false;
    }
    public String toString(){
        String user = "";
        for (Object a : id){
            user+=a;
        }
        return user;
    }

}

