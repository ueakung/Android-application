package com.example.bus;

import java.util.ArrayList;

public class user {
    public String userName;
    public String password1;
    public String password2;
    public String email;

    public user(String email, String userName, String password1, String password2) {
        this.email = email;
        this.password1 = password1;
        this.userName = userName;
        this.password2 = password2;
    }

    public boolean user_information(String email, String userName, String password1, String password2) {

        ArrayList<String> userData = new ArrayList<>();
        for (int i = 0; i < userData.size(); i++) {
            if (password1.length() >= 8 && password1.equals(password2) && userData.get(i) != userName) {
                userData.add(userName);

                return true;
            }
        }
        return false;
    }
    public boolean password_information(String email, String userName, String password1, String password2){
        ArrayList<String> password = new ArrayList<>();
        for (int i = 0; i < password.size(); i++) {
            if (password1.equals(password2)) {

                password.add(password1);
                return true;
            }
        }
        return false;
    }

}
//    public String getUser(){
//        return userName.toString();
//    }
//    public String getPassword(){
//        return password1.toString();
//    }
//    public String getEmail(){
//        return email.toString();
//    }


