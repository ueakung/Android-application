package com.example.bus;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(register.this,MainActivity.class);
                startActivity(intent);
            }
        });
        ImageView register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(register.this, signIn.class);
                TextView email = findViewById(R.id.email);
                String input_email = email.getText().toString();
                TextView username = findViewById(R.id.username);
                String input_user = username.getText().toString();
                TextView password1 = findViewById(R.id.password1);
                String input_password1 = password1.getText().toString();
                TextView password2 = findViewById(R.id.password2);
                String input_password2 = password2.getText().toString();
                ArrayList<String> email_information = new ArrayList<>();
                ArrayList<String> user_information = new ArrayList<>();
                ArrayList<String> password_information = new ArrayList<>();
                for (int i = 0; i < user_information.size(); i++) {
                    if (input_user.length() >= 6 && password1.length() >= 8 &&  password1.equals(password2)) {
                        if(user_information == null && password_information == null){
                            user_information.add(input_user);
                            password_information.add(input_password1);
                            email_information.add(input_email);
                            startActivity(intent2);
                        }else if(user_information.get(i) != input_user ){
                            user_information.add(input_user);
                            password_information.add(input_password1);
                            email_information.add(input_email);
                            startActivity(intent2);
                        }

                    }else{
                        Toast.makeText(getApplicationContext(),"this username has already use \n      or password is wrong ",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}




//                user information = new user(input_email, input_user, input_password1, input_password2);

//                if(information.user_information(input_email,input_user,input_password1,input_password2)){
//                    startActivity(intent2);
//                }else{
//                    if(input_email == null){
//                        Toast.makeText(getApplicationContext(),"please enter your email",Toast.LENGTH_LONG).show();
//                    }else if(input_user == null){
//                        Toast.makeText(getApplicationContext(),"please enter your username ",Toast.LENGTH_LONG).show();
//                    }else if(input_password1 == null){
//                        Toast.makeText(getApplicationContext(),"please enter your password",Toast.LENGTH_LONG).show();
//                    }else if(input_password2 == null){
//                        Toast.makeText(getApplicationContext(),"please enter your password",Toast.LENGTH_LONG).show();
//                    }else{
//                        Toast.makeText(getApplicationContext(),"this username has already use \n      or password is wrong ",Toast.LENGTH_LONG).show();
//                    }
//                }
//            }
//        });


