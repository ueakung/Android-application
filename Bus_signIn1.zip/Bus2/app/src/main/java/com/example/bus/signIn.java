package com.example.bus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class signIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        TextView register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signIn.this,register.class);
                startActivity(intent);
            }
        });
        ImageView signIn = findViewById(R.id.signIn);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(signIn.this, SelectBus.class);
                TextView input_userName = findViewById(R.id.username);
                String username = input_userName.getText().toString();
                TextView input_password = findViewById(R.id.password);
                String password = input_password.getText().toString();
                id member = new id(username,password);
                if (member.login("abc", "123")) {
                    startActivity(intent2);
                }else {
                    Toast.makeText(getApplicationContext(),"username or password is incorrect",Toast.LENGTH_LONG).show();

                }

            }
        });

    }
}
